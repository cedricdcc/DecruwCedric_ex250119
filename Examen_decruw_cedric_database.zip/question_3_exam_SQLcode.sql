-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`gene`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`gene` (
  `gene_name` INT NOT NULL,
  `gene_id` VARCHAR(45) NOT NULL,
  `gene_start` INT(18) NULL,
  `gene_end` INT(18) NULL,
  `Chromosome` CHAR(2) NOT NULL,
  PRIMARY KEY (`gene_id`),
  UNIQUE INDEX `gene_id_UNIQUE` (`gene_id` ASC) VISIBLE)
ENGINE = InnoDB
COMMENT = 'Gene table containing info about gene';


-- -----------------------------------------------------
-- Table `mydb`.`Syndrome`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Syndrome` (
  `idSyndrome` INT NOT NULL,
  `desc_syndrome` VARCHAR(6000) NOT NULL,
  `desc_aff_gene` VARCHAR(6000) NULL,
  `Syndrome` VARCHAR(45) NOT NULL,
  `Syndrome_start` INT(18) NULL,
  `Syndrome_end` INT(18) NULL,
  `Syndrome_chromosome` CHAR(2) NULL,
  PRIMARY KEY (`idSyndrome`),
  UNIQUE INDEX `idSyndrome_UNIQUE` (`idSyndrome` ASC) VISIBLE)
ENGINE = InnoDB
COMMENT = 'desc sydrome and short comment';


-- -----------------------------------------------------
-- Table `mydb`.`Patient`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Patient` (
  `idPatient` INT NOT NULL COMMENT 'is ID van in de vraag.',
  `Patient_name` VARCHAR(45) NOT NULL,
  `Patient_gender` ENUM("M", "F") NOT NULL,
  `Patient_Age` INT(3) NOT NULL,
  `Syndrome` VARCHAR(45) NULL,
  `Syndrome_idSyndrome` INT NOT NULL,
  PRIMARY KEY (`idPatient`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`gene_has_Syndrome`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`gene_has_Syndrome` (
  `gene_gene_id` VARCHAR(45) NOT NULL,
  `Syndrome_idSyndrome` INT NOT NULL,
  PRIMARY KEY (`gene_gene_id`, `Syndrome_idSyndrome`),
  INDEX `fk_gene_has_Syndrome_Syndrome1_idx` (`Syndrome_idSyndrome` ASC) VISIBLE,
  INDEX `fk_gene_has_Syndrome_gene_idx` (`gene_gene_id` ASC) VISIBLE,
  CONSTRAINT `fk_gene_has_Syndrome_gene`
    FOREIGN KEY (`gene_gene_id`)
    REFERENCES `mydb`.`gene` (`gene_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_gene_has_Syndrome_Syndrome1`
    FOREIGN KEY (`Syndrome_idSyndrome`)
    REFERENCES `mydb`.`Syndrome` (`idSyndrome`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Syndrome_has_Patient`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Syndrome_has_Patient` (
  `Syndrome_idSyndrome` INT NOT NULL,
  `Patient_idPatient` INT NOT NULL,
  PRIMARY KEY (`Syndrome_idSyndrome`, `Patient_idPatient`),
  INDEX `fk_Syndrome_has_Patient_Patient1_idx` (`Patient_idPatient` ASC) VISIBLE,
  INDEX `fk_Syndrome_has_Patient_Syndrome1_idx` (`Syndrome_idSyndrome` ASC) VISIBLE,
  CONSTRAINT `fk_Syndrome_has_Patient_Syndrome1`
    FOREIGN KEY (`Syndrome_idSyndrome`)
    REFERENCES `mydb`.`Syndrome` (`idSyndrome`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Syndrome_has_Patient_Patient1`
    FOREIGN KEY (`Patient_idPatient`)
    REFERENCES `mydb`.`Patient` (`idPatient`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Mutations`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Mutations` (
  `idMutations` INT NOT NULL,
  `Mutation_start` INT(18) NOT NULL,
  `Mutation_end` INT(18) NOT NULL,
  `Mutation_chromosome` CHAR(2) NULL,
  `Patient_idPatient` INT NOT NULL,
  PRIMARY KEY (`idMutations`, `Patient_idPatient`),
  INDEX `fk_Mutations_Patient1_idx` (`Patient_idPatient` ASC) VISIBLE,
  CONSTRAINT `fk_Mutations_Patient1`
    FOREIGN KEY (`Patient_idPatient`)
    REFERENCES `mydb`.`Patient` (`idPatient`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Mutations_has_gene`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Mutations_has_gene` (
  `Mutations_idMutations` INT NOT NULL,
  `Mutations_Patient_idPatient` INT NOT NULL,
  `gene_gene_id` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Mutations_idMutations`, `Mutations_Patient_idPatient`, `gene_gene_id`),
  INDEX `fk_Mutations_has_gene_gene1_idx` (`gene_gene_id` ASC) VISIBLE,
  INDEX `fk_Mutations_has_gene_Mutations1_idx` (`Mutations_idMutations` ASC, `Mutations_Patient_idPatient` ASC) VISIBLE,
  CONSTRAINT `fk_Mutations_has_gene_Mutations1`
    FOREIGN KEY (`Mutations_idMutations` , `Mutations_Patient_idPatient`)
    REFERENCES `mydb`.`Mutations` (`idMutations` , `Patient_idPatient`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Mutations_has_gene_gene1`
    FOREIGN KEY (`gene_gene_id`)
    REFERENCES `mydb`.`gene` (`gene_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Syndrome_has_Mutations`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Syndrome_has_Mutations` (
  `Syndrome_idSyndrome` INT NOT NULL,
  `Mutations_idMutations` INT NOT NULL,
  `Mutations_Patient_idPatient` INT NOT NULL,
  PRIMARY KEY (`Syndrome_idSyndrome`, `Mutations_idMutations`, `Mutations_Patient_idPatient`),
  INDEX `fk_Syndrome_has_Mutations_Mutations1_idx` (`Mutations_idMutations` ASC, `Mutations_Patient_idPatient` ASC) VISIBLE,
  INDEX `fk_Syndrome_has_Mutations_Syndrome1_idx` (`Syndrome_idSyndrome` ASC) VISIBLE,
  CONSTRAINT `fk_Syndrome_has_Mutations_Syndrome1`
    FOREIGN KEY (`Syndrome_idSyndrome`)
    REFERENCES `mydb`.`Syndrome` (`idSyndrome`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Syndrome_has_Mutations_Mutations1`
    FOREIGN KEY (`Mutations_idMutations` , `Mutations_Patient_idPatient`)
    REFERENCES `mydb`.`Mutations` (`idMutations` , `Patient_idPatient`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
